let modelFeatures = [];
let catFeatures = [];
let featureOptions = {};

const base_url = 'http://localhost:8800/api/v1'

// Загрузка информации о модели
async function loadModelInfo() {
    const response = await fetch(`${base_url}/model_info`);
    const data = await response.json();

    document.getElementById('model-type').textContent = data.model_type;
    document.getElementById('current-model').textContent = data.current_model;
    document.getElementById('loaded-at').textContent = data.loaded_at;

    modelFeatures = data.features;
    catFeatures = data.cat_features;
}

async function loadFeatureOptions() {
  // В реальном приложении здесь должен быть запрос к API
  // который возвращает уникальные значения для каждой фичи
  // Для демонстрации используем фиктивные данные

  featureOptions = {
    'utm_source': ['google', 'yandex', 'email', 'direct', 'social'],
    'utm_medium': ['cpc', 'organic', 'referral', 'email', 'social'],
    'device_brand': ['Apple', 'Samsung', 'Xiaomi', 'Huawei', 'Other'],
    'visit_number': [1, 2, 3, 4, 5],
    'utm_campaign': ['summer_sale', 'winter_sale', 'new_year', 'black_friday', 'unknown'],
    'utm_keyword': ['car_loan', 'mortgage', 'credit_card', 'insurance', 'unknown']
  };
}

// Отправка формы
async function submitForm() {
  // Собираем данные формы
  const formData = {};
  modelFeatures.forEach(feature => {
    const element = document.getElementById(feature);
    formData[feature] = element.value;
  });

  // Проверяем, что все поля заполнены
  if (Object.values(formData).some(value => !value)) {
    alert('Пожалуйста, заполните все поля формы');
    return;
  }

  try {
    // Показываем индикатор загрузки
    loading.style.display = 'block';
    result.style.display = 'none';

    // Отправляем запрос к API
    const response = await fetch('/api/v1/predict', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(formData)
    });

    if (!response.ok) {
      throw new Error(`Ошибка HTTP: ${response.status}`);
    }

    const data = await response.json();

    // Отображаем результат
    document.getElementById('probability').textContent = data.probability.toFixed(4);
    document.getElementById('prediction').textContent = data.prediction;
    document.getElementById('timestamp').textContent = data.timestamp;
    result.style.display = 'block';

  } catch (error) {
    console.error('Ошибка при отправке формы:', error);
    alert(`Произошла ошибка: ${error.message}`);
  } finally {
    loading.style.display = 'none';
  }
}
